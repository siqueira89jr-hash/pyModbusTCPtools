# pyModbusTCPtools

Biblioteca Python para facilitar comunicação Modbus TCP, adicionando:
- Leitura e escrita tipada
- Endianness avançado
- Operações seguras (safe)
- Tratamento de exceções

## Instalação (local)

```bash
pip install pyModbusTCPtools-0.1.0-py3-none-any.whl
